        <?php include 'layout/header.php';?>       
        
            <!-- Page Sidebar -->
            <div class="page-sidebar">
                <a class="logo-box" href="index.php">
                    <span>D.I.Academy</span>
                    <i class="icon-radio_button_checked" id="fixed-sidebar-toggle-button"></i>
                    <i class="icon-close" id="sidebar-toggle-button-close"></i>
                </a>
                <div class="page-sidebar-inner">
                    <div class="page-sidebar-menu">
                        <ul class="accordion-menu">
                            <li class="active-page">
                                <a href="index.php">
                                    <i class="menu-icon icon-home4"></i><span>Dashboard</span>
                                </a>
                            </li>
                            <li>
                                <a href="Upload.php">
                                    <i class="fa fa-upload"></i><span><span>&nbsp&nbsp&nbsp
                                    </span> Upload</span>
                                </a>
                            </li>
                            <li>
                                <a href="UploadedDoc.php">
                                    <i class="fa fa-file"></i><span><span>&nbsp&nbsp&nbsp
                                    </span> Uploaded docs</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- /Page Sidebar -->
            
                <?php include 'layout/inner_header.php';?>

                    <div class="page-title">
                        <h3 class="animated fadeInDown breadcrumb-header">Dashboard</h3>
                    </div>
                    <div id="main-wrapper">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-white stats-widget">
                                    <div class="panel-body">
                                        <div class="pull-left">
                                            <span class="stats-number">Dashboard</span>
                                            <p class="stats-info">dashboard</p>
                                        </div>
                                        <div class="pull-right">
                                            <i class="fa fa-home stats-icon"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-white stats-widget">
                                    <div class="panel-body">
                                        <div class="pull-left">
                                            <span class="stats-number">Dashboard</span>
                                            <p class="stats-info">dashboard</p>
                                        </div>
                                        <div class="pull-right">
                                            <i class="fa fa-home stats-icon"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-white stats-widget">
                                    <div class="panel-body">
                                        <div class="pull-left">
                                            <span class="stats-number">Dashboard</span>
                                            <p class="stats-info">dashboard</p>
                                        </div>
                                        <div class="pull-right">
                                            <i class="fa fa-home stats-icon"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-white stats-widget">
                                    <div class="panel-body">
                                        <div class="pull-left">
                                            <span class="stats-number">Dashboard</span>
                                            <p class="stats-info">dashboard</p>
                                        </div>
                                        <div class="pull-right">
                                            <i class="fa fa-home stats-icon"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Row -->
                        
                        </div><!-- Row -->
                    
                    <div class="page-footer">
                    </div>
                
        <?php include 'layout/footer.php';?>       
        