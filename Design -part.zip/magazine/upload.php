            <?php include 'layout/header.php';?>       
     
            <!-- Page Sidebar -->
            <div class="page-sidebar">
                <a class="logo-box" href="index.php">
                    <span>D.I.Academy</span>
                    <i class="icon-radio_button_checked" id="fixed-sidebar-toggle-button"></i>
                    <i class="icon-close" id="sidebar-toggle-button-close"></i>
                </a>
                <div class="page-sidebar-inner">
                    <div class="page-sidebar-menu">
                        <ul class="accordion-menu">
                            <li>
                                <a href="index.php">
                                    <i class="menu-icon icon-home4"></i><span>Dashboard</span>
                                </a>
                            </li>
                             <li class="active-page">
                                 <a href="Upload.php">
                                     <i class="fa fa-upload"></i><span><span>&nbsp&nbsp&nbsp
                                     </span> Upload</span>
                                 </a>
                             </li>
                             <li>
                                 <a href="UploadedDoc.php">
                                     <i class="fa fa-file"></i><span><span>&nbsp&nbsp&nbsp
                                     </span> Uploaded docs</span>
                                 </a>
                             </li>
                         </ul>
                    </div>
                </div>
            </div><!-- /Page Sidebar -->
            
                <?php include 'layout/inner_header.php';?>


                    


                    
        
            <div class="con">
                <form class="">
                    <div class="panel-heading clearfix">
                        <h4 class="animated fadeInDown panel-title">Upload your article</h4>
                    </div>

                    <div class="wrap-input100 m-b-23">
                        <span class="label-input100">Name</span>
                        <input class="input100" type="text" name="name" placeholder="Type your name">
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>

                    <div class="wrap-input100  m-b-23">
                        <span class="label-input100">Article title</span>
                        <input class="input100" type="text" name="title" placeholder="Title of your article">
                        <span class="focus-input100" data-symbol="&#x268d;"></span>
                    </div>

                    <div id="main-wrapper">   
                        <div class="col-md-12">
                            <div class="panel panel-white">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title">Upload doc. & images-(not must)</h4>
                                </div>
                                <div class="panel-body">
                                    <div id="uploader">
                                        <p>Your browser doesn't have Flash, Silverlight or HTML5 support.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- Main Wrapper -->

                    <div>
                        <h4 class="term-line"><input type="checkbox"> I accept the <a href="signup.php" data-toggle="modal" 
                    data-target=".bs-example-modal-lg">Terms and Conditions</a></h4>
                    </div>
                    


                    <div>
                    <button type="Submit" class="splupload_button" > Submit </button>
                    <button type="Reset" class="rplupload_button"> Reset </button>
                    </div>
            
                </form>
            </div>
        

               <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                       <div class="modal-dialog modal-lg">
                           <div class="modal-content">
                               <div class="modal-header">
                                   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                   <h4 class="modal-title" id="myLargeModalLabel">Terms & Conditions</h4>
                               </div>
                               <div class="modal-body">
                                   <h4>Lorem Ipsum</h4>
                                   Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.<br><br><hr>
                                   <h4>Dolor sit amet</h4>
                                   Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.<br><br>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.<br><br><hr>
                                   <h4>Consectetuer</h4>
                                   Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.<br><br><br>
                                   <h4>Lorem Ipsum</h4>
                                   Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.<br><br><hr>
                                   <h4>Dolor sit amet</h4>
                                   Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.<br><br>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.<br><br><hr>
                                   <h4>Consectetuer</h4>
                                   Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.<br><br>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                               </div>
                               <div class="modal-footer">
                                   <button type="button" class="btn btn-danger" data-dismiss="modal">Decline</button>
                                   <button type="button" class="btn btn-info" data-dismiss="modal">I Agree the Terms</button>
                               </div>
                           </div>
                       </div>
                   </div>


            <?php include 'layout/footer.php';?>