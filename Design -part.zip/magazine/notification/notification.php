         <li class="dropdown">
           <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bell"></i></a>
           <ul class="dropdown-menu dropdown-lg dropdown-content">
               <li class="drop-title">Notifications<a href="#" class="drop-title-link"><i class="fa fa-angle-right"></i></a></li>
               <li class="slimscroll dropdown-notifications">
                   <ul class="list-unstyled dropdown-oc">
                       <li>
                           <a href="#"><span class="notification-badge bg-primary"><i class="fa fa-photo"></i></span>
                               <span class="notification-info">Lorem ipsum dolor sit amet elit sit amet elit<b>"Lorem ipsum"</b>.
                                   <small class="notification-date">20:00</small>
                               </span></a>
                       </li>
                       <li>
                           <a href="#"><span class="notification-badge bg-primary"><i class="fa fa-at"></i></span>
                               <span class="notification-info">Lorem ipsum dolor sit amet elit <b>"Lorem ipsum"</b>.
                                   <small class="notification-date">06:07</small>
                               </span></a>
                       </li>
                       <li>
                           <a href="#"><span class="notification-badge bg-danger"><i class="fa fa-bolt"></i></span>
                               <span class="notification-info">Lorem ipsum dolor sit amet elit sit amet elit <b>"Lorem ipsum"</b>.
                                   <small class="notification-date">Yesterday</small>
                               </span></a>
                       </li>
                       <li>
                           <a href="#"><span class="notification-badge bg-success"><i class="fa fa-bullhorn"></i></span>
                               <span class="notification-info">Lorem ipsum dolor sit amet elit <b>"Lorem ipsum"</b>.
                                   <small class="notification-date">Yesterday</small>
                               </span></a>
                           </li>
                       </ul>
                   </li>
               </ul>
           </li>